const nodemailer = require('nodemailer');
const sdk = require('node-appwrite');

const REQUIRED_ENV = [
  'APPWRITE_FUNCTION_ENDPOINT',
  'APPWRITE_FUNCTION_PROJECT_ID',
  'APPWRITE_FUNCTION_API_KEY',
  'APPWRITE_DATABASE_ID',
  'APPWRITE_USERS_COLLECTION_ID',
  'SMTP_HOST',
  'SMTP_PORT',
  'SMTP_USER',
  'SMTP_PASS',
  'SMTP_FROM_EMAIL'
];

function assertEnv() {
  const missing = REQUIRED_ENV.filter((key) => !process.env[key]);
  if (missing.length > 0) {
    throw new Error(`Missing environment variables: ${missing.join(', ')}`);
  }
}

function parseJsonBody(req) {
  try {
    return JSON.parse(req.bodyRaw || '{}');
  } catch {
    return {};
  }
}

function normalizeBoolean(value) {
  return value === true || value === 'true' || value === 1 || value === '1';
}

function extractEventPayload(req) {
  const body = parseJsonBody(req);

  if (body && typeof body.payload === 'object' && body.payload !== null) {
    return body.payload;
  }

  if (body && typeof body.data === 'object' && body.data !== null) {
    return body.data;
  }

  return body;
}

function createTransporter() {
  const smtpPort = Number(process.env.SMTP_PORT);
  const smtpPass = String(process.env.SMTP_PASS || '').replace(/\s+/g, '');

  return nodemailer.createTransport({
    host: String(process.env.SMTP_HOST || '').trim(),
    port: smtpPort,
    secure: smtpPort === 465,
    auth: {
      user: process.env.SMTP_USER,
      pass: smtpPass
    }
  });
}

async function sendWelcomeEmail(toEmail, displayName) {
  const transporter = createTransporter();
  const appName = process.env.APP_NAME || 'Easy Drive Driving School';

  await transporter.sendMail({
    from: `"${appName}" <${process.env.SMTP_FROM_EMAIL}>`,
    to: toEmail,
    subject: `Welcome to ${appName}! Your account is approved`,
    text: `Hi ${displayName}, your account is now approved. You can now log in and start using ${appName}.`,
    html: `
      <div style="font-family: Arial, sans-serif; color: #1f2937; line-height: 1.5;">
        <h2 style="margin-bottom: 8px;">Welcome to ${appName}</h2>
        <p>Hi <strong>${displayName}</strong>,</p>
        <p>Your account has been approved by our admin team.</p>
        <p>You can now sign in and start using the app.</p>
        <p style="margin-top: 20px;">Drive smart and stay safe.</p>
      </div>
    `
  });
}

async function markWelcomeEmailSent(documentId) {
  const client = new sdk.Client()
    .setEndpoint(process.env.APPWRITE_FUNCTION_ENDPOINT)
    .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
    .setKey(process.env.APPWRITE_FUNCTION_API_KEY);

  return new sdk.Databases(client).updateDocument(
    process.env.APPWRITE_DATABASE_ID,
    process.env.APPWRITE_USERS_COLLECTION_ID,
    documentId,
    {
      welcomeEmailSent: true,
      welcomeEmailSentAt: new Date().toISOString()
    }
  );
}

async function getUserDocument(documentId) {
  const client = new sdk.Client()
    .setEndpoint(process.env.APPWRITE_FUNCTION_ENDPOINT)
    .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
    .setKey(process.env.APPWRITE_FUNCTION_API_KEY);

  return new sdk.Databases(client).getDocument(
    process.env.APPWRITE_DATABASE_ID,
    process.env.APPWRITE_USERS_COLLECTION_ID,
    documentId
  );
}

module.exports = async ({ req, res, log, error }) => {
  try {
    assertEnv();

    let payload = extractEventPayload(req);
    const documentId = String(payload.$id || '').trim();

    if (documentId) {
      const emailFromEvent = String(payload.email || '').trim();
      if (!emailFromEvent) {
        try {
          const fullDoc = await getUserDocument(documentId);
          payload = { ...fullDoc, ...payload };
        } catch (fetchError) {
          error(`Failed to fetch document ${documentId}: ${fetchError.message}`);
        }
      }
    }

    const isApproved = normalizeBoolean(payload.approved);
    const hasWelcomeEmailSent = normalizeBoolean(payload.welcomeEmailSent);
    const email = String(payload.email || '').trim();
    const name = String(payload.name || 'Student').trim();

    if (!documentId || !email) {
      log(`Skipped welcome email: missing_document_or_email (id=${documentId || 'none'}, email=${email || 'none'})`);
      return res.json({ skipped: true, reason: 'missing_document_or_email' });
    }

    if (!isApproved) {
      log(`Skipped welcome email for ${documentId}: not_approved`);
      return res.json({ skipped: true, reason: 'not_approved' });
    }

    if (hasWelcomeEmailSent) {
      log(`Skipped welcome email for ${documentId}: already_sent`);
      return res.json({ skipped: true, reason: 'already_sent' });
    }

    await sendWelcomeEmail(email, name);

    try {
      await markWelcomeEmailSent(documentId);
    } catch (markError) {
      // Email was already sent. Log update failure so schema can be fixed.
      error(`Failed to mark welcomeEmailSent for ${documentId}: ${markError.message}`);
    }

    log(`Welcome email sent to ${email}`);
    return res.json({ success: true, email });
  } catch (err) {
    error(err.message || String(err));
    return res.json({ success: false, error: err.message || 'unknown_error' }, 500);
  }
};
